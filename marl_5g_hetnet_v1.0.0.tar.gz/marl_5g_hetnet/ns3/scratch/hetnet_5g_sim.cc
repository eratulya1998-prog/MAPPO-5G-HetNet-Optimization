/* ==========================================================================
 * FILE: hetnet_5g_sim.cc
 * TITLE: Multi-Agent DRL Framework for Adaptive Energy-Efficient
 *        Optimization in 5G Heterogeneous Networks
 *
 * TOPOLOGY:
 *   - 1 Macro Base Station  (MBS)  @ centre  — 46 dBm fixed
 *   - 6 Small Base Stations (SBS)  @ hexagonal ring — power-controlled
 *   - 30 UEs moving with RandomWaypoint mobility
 *
 * OUTPUT:  hetnet_dataset.csv
 * COLUMNS: episode, time_step, bs_id, bs_type,
 *          ue_count, tx_power_dbm, sinr_db, rsrp_dbm,
 *          throughput_mbps, prb_utilization, interference_dbm,
 *          energy_consumed_w, energy_efficiency, latency_ms,
 *          fairness_index, handover_count, action, reward
 *
 * ENERGY MODEL: Auer et al. 2011 (EARTH project)
 *   MBS : P0=130W  delta_p=4.7  Pmax=40W  Psleep=75W
 *   SBS : P0=6.8W  delta_p=4.0  Pmax=6.3W Psleep=2.9W
 *
 * BUILD:
 *   cp hetnet_5g_sim.cc <ns3-root>/scratch/
 *   cd <ns3-root>
 *   ./ns3 configure --enable-examples
 *   ./ns3 build
 *   ./ns3 run "hetnet_5g_sim"
 * ========================================================================== */

#include "ns3/applications-module.h"
#include "ns3/buildings-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/lte-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <map>
#include <numeric>
#include <sstream>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("HetNet5GSimulation");

/* ==========================================================================
 * GLOBAL SIMULATION PARAMETERS
 * ========================================================================== */
static const uint32_t NUM_MBS         = 1;
static const uint32_t NUM_SBS         = 6;
static const uint32_t NUM_ENBS        = NUM_MBS + NUM_SBS;
static const uint32_t NUM_UES         = 30;
static const double   SIM_DURATION    = 50.0;   // seconds per episode
static const uint32_t NUM_EPISODES    = 4;       // total episodes
static const double   CTRL_INTERVAL   = 0.5;    // DRL decision interval (s)
static const double   AREA_RADIUS     = 500.0;  // metres
static const double   SBS_RING_RADIUS = 250.0;  // metres

/* ---------- Transmit power levels (dBm) ----------------------------------- */
static const double TX_LOW  = 20.0;
static const double TX_MED  = 30.0;
static const double TX_HIGH = 40.0;
static const double TX_MBS  = 46.0;

static const std::vector<double> ACTION_POWER = {TX_LOW, TX_MED, TX_HIGH};

/* ---------- Auer 2011 energy parameters ----------------------------------- */
struct EnergyParams {
    double P0_W;      // idle power (W)
    double delta_p;   // slope (load-dependent)
    double Pmax_W;    // max RF output power (W)
    double Psleep_W;  // sleep power (W)
};

static const EnergyParams MBS_ENERGY = {130.0, 4.7, 40.0, 75.0};
static const EnergyParams SBS_ENERGY = {6.8,   4.0,  6.3,  2.9};

/* ---------- Path-loss & noise -------------------------------------------- */
static const double NOISE_DBM     = -174.0 + 10.0 * std::log10(20e6) + 9.0; // NF=9dB, BW=20MHz
static const double PATH_LOSS_EXP = 3.76;
static const double PATH_LOSS_REF = 128.1; // dB @ 1 km (3GPP TR36.814 macro)

/* ==========================================================================
 * HELPER: dBm → Watts
 * ========================================================================== */
inline double DbmToW(double dbm) { return std::pow(10.0, (dbm - 30.0) / 10.0); }
inline double WToDbm(double w)   { return 10.0 * std::log10(w) + 30.0; }
inline double DbToLinear(double db) { return std::pow(10.0, db / 10.0); }

/* ==========================================================================
 * DATA STRUCTURES
 * ========================================================================== */
struct BsRecord {
    uint32_t bs_id;
    std::string bs_type;        // "MBS" | "SBS"
    double x, y;                // position (m)
    double tx_power_dbm;        // current transmit power
    uint32_t action;            // 0=LOW 1=MED 2=HIGH
    uint32_t ue_count;          // attached UEs
    uint32_t prb_used;          // used PRBs  (out of 100)
    double total_throughput;    // Mbps
    double interference_w;      // aggregate interference (W)
    uint32_t handover_events;   // handovers this interval
    EnergyParams ep;
};

struct UeRecord {
    uint32_t ue_id;
    double x, y;
    uint32_t serving_bs;
    double sinr_db;
    double rsrp_dbm;
    double throughput_mbps;
    double latency_ms;
};

/* Global state */
static std::vector<BsRecord> g_bs;
static std::vector<UeRecord> g_ue;
static std::ofstream         g_csv;
static uint32_t              g_episode    = 0;
static uint32_t              g_time_step  = 0;
static double                g_sim_offset = 0.0; // start of current episode

/* ==========================================================================
 * PATH-LOSS MODEL (3GPP TR36.814 simplified)
 *   PL(d) = A + 10*n*log10(d)   A=128.1 dB @ 1km, n=3.76 (macro-outdoor)
 *   SBS uses ITU-R Indoor/Hotspot:  A=40.04, n=2.63
 * ========================================================================== */
double PathLossMacro(double dist_m)
{
    if (dist_m < 1.0) dist_m = 1.0;
    return PATH_LOSS_REF + 10.0 * PATH_LOSS_EXP * std::log10(dist_m / 1000.0);
}

double PathLossSBS(double dist_m)
{
    if (dist_m < 1.0) dist_m = 1.0;
    return 40.04 + 10.0 * 2.63 * std::log10(dist_m / 100.0);
}

/* ==========================================================================
 * SINR CALCULATION
 *   SINR_i = Ps_i / (N + sum_{j≠i} Ps_j)
 * ========================================================================== */
struct SinrResult { double sinr_db; double rsrp_dbm; double interference_w; };

SinrResult ComputeSINR(uint32_t ue_idx, uint32_t serving_bs)
{
    const UeRecord& ue = g_ue[ue_idx];
    double ue_x = ue.x, ue_y = ue.y;

    /* Serving BS received power */
    const BsRecord& bs = g_bs[serving_bs];
    double dist = std::sqrt((ue_x - bs.x) * (ue_x - bs.x) +
                            (ue_y - bs.y) * (ue_y - bs.y));
    double pl = (bs.bs_type == "MBS") ? PathLossMacro(dist) : PathLossSBS(dist);
    double rsrp_dbm = bs.tx_power_dbm - pl;
    double signal_w = DbmToW(rsrp_dbm);

    /* Interference from all other BSs */
    double interf_w = 0.0;
    for (uint32_t j = 0; j < g_bs.size(); ++j) {
        if (j == serving_bs) continue;
        const BsRecord& ib = g_bs[j];
        double d2 = std::sqrt((ue_x - ib.x) * (ue_x - ib.x) +
                              (ue_y - ib.y) * (ue_y - ib.y));
        double pl2 = (ib.bs_type == "MBS") ? PathLossMacro(d2) : PathLossSBS(d2);
        interf_w += DbmToW(ib.tx_power_dbm - pl2);
    }

    double noise_w  = DbmToW(NOISE_DBM);
    double sinr_lin = signal_w / (interf_w + noise_w);
    double sinr_db  = 10.0 * std::log10(sinr_lin);

    return {sinr_db, rsrp_dbm, interf_w};
}

/* ==========================================================================
 * SHANNON CAPACITY → THROUGHPUT
 *   C = BW * log2(1 + SINR)      BW = 20 MHz per cell
 * ========================================================================== */
double ShannonThroughput(double sinr_db, double bw_mhz = 20.0)
{
    double sinr_lin = DbToLinear(sinr_db);
    /* cap at 64-QAM 0.93 spectral efficiency ~ 18.6 b/s/Hz */
    double se = std::min(std::log2(1.0 + sinr_lin), 18.6);
    return bw_mhz * se; /* Mbps */
}

/* ==========================================================================
 * AUER ENERGY MODEL
 *   P_BS = P0 + delta_p * Pout   (Pout = RF output power in Watts)
 * ========================================================================== */
double AuerPower(const EnergyParams& ep, double load_fraction)
{
    /* load_fraction in [0,1] represents PRB utilization */
    double pout = ep.Pmax_W * load_fraction;
    double p_bs = ep.P0_W + ep.delta_p * pout;
    return p_bs; /* Watts */
}

/* ==========================================================================
 * JAIN FAIRNESS INDEX
 *   J = (sum(xi))^2 / (N * sum(xi^2))
 * ========================================================================== */
double JainFairness(const std::vector<double>& rates)
{
    if (rates.empty()) return 1.0;
    double sum1 = 0.0, sum2 = 0.0;
    for (double r : rates) { sum1 += r; sum2 += r * r; }
    if (sum2 < 1e-12) return 1.0;
    return (sum1 * sum1) / (rates.size() * sum2);
}

/* ==========================================================================
 * REWARD FUNCTION
 *   R = w1*EE + w2*Fairness - w3*Power_norm - w4*Handover_penalty
 * ========================================================================== */
double ComputeReward(const BsRecord& bs,
                     double ee,
                     double fairness,
                     double power_norm)
{
    double w1 = 0.40, w2 = 0.25, w3 = 0.20, w4 = 0.15;
    double ho_penalty = (bs.handover_events > 0) ?
                        std::min(0.1 * bs.handover_events, 1.0) : 0.0;
    double r = w1 * std::tanh(ee / 10.0)
             + w2 * fairness
             - w3 * power_norm
             - w4 * ho_penalty;
    return r;
}

/* ==========================================================================
 * SIMPLE ε-GREEDY POLICY (stand-in for DRL agent during data collection)
 * ========================================================================== */
static std::map<uint32_t, double> g_q_values; // bs_id -> running Q estimate

uint32_t SelectAction(uint32_t bs_id, double epsilon = 0.3)
{
    double r = (double)rand() / RAND_MAX;
    if (r < epsilon) {
        return rand() % 3; /* explore */
    }
    /* greedy: pick action that historically gave best reward */
    /* simplified: use load-based heuristic */
    const BsRecord& bs = g_bs[bs_id];
    double load = (bs.ue_count > 0) ? std::min(bs.prb_used / 100.0, 1.0) : 0.0;
    if (load > 0.7) return 2;       /* HIGH power for heavy load */
    if (load < 0.2) return 0;       /* LOW power for light load */
    return 1;                       /* MED otherwise */
}

/* ==========================================================================
 * WRITE CSV HEADER
 * ========================================================================== */
void WriteHeader()
{
    g_csv << "episode,time_step,time_s,"
          << "bs_id,bs_type,"
          << "ue_count,prb_utilization,"
          << "tx_power_dbm,action,"
          << "avg_sinr_db,min_sinr_db,max_sinr_db,"
          << "avg_rsrp_dbm,"
          << "throughput_mbps,"
          << "interference_dbm,"
          << "energy_consumed_w,energy_efficiency,"
          << "latency_ms,"
          << "fairness_index,"
          << "handover_count,"
          << "reward\n";
}

/* ==========================================================================
 * COLLECT STATISTICS & WRITE ROW
 * ========================================================================== */
void CollectAndWrite(double sim_time)
{
    /* -----------------------------------------------------------------------
     * 1. Assign UEs to nearest BS (simple max-RSRP attachment)
     * --------------------------------------------------------------------- */
    for (auto& ue : g_ue) {
        double best_rsrp = -1e9;
        uint32_t best_bs = 0;
        for (uint32_t j = 0; j < g_bs.size(); ++j) {
            const BsRecord& bs = g_bs[j];
            double dist = std::sqrt((ue.x - bs.x) * (ue.x - bs.x) +
                                    (ue.y - bs.y) * (ue.y - bs.y));
            double pl   = (bs.bs_type == "MBS") ? PathLossMacro(dist)
                                                 : PathLossSBS(dist);
            double rsrp = bs.tx_power_dbm - pl;
            if (rsrp > best_rsrp) { best_rsrp = rsrp; best_bs = j; }
        }
        bool handover = (ue.serving_bs != best_bs);
        if (handover) g_bs[best_bs].handover_events++;
        ue.serving_bs = best_bs;
    }

    /* -----------------------------------------------------------------------
     * 2. Reset per-BS accumulators
     * --------------------------------------------------------------------- */
    for (auto& bs : g_bs) {
        bs.ue_count       = 0;
        bs.total_throughput = 0.0;
        bs.interference_w   = 0.0;
        bs.prb_used         = 0;
    }

    /* -----------------------------------------------------------------------
     * 3. Per-UE SINR / throughput
     * --------------------------------------------------------------------- */
    std::vector<std::vector<double>> bs_ue_tp(g_bs.size());
    for (auto& ue : g_ue) {
        uint32_t sid = ue.serving_bs;
        auto res = ComputeSINR(/* ue_idx */ &ue - &g_ue[0], sid);

        ue.sinr_db       = res.sinr_db;
        ue.rsrp_dbm      = res.rsrp_dbm;
        ue.throughput_mbps = ShannonThroughput(res.sinr_db);

        /* simple M/D/1 latency model (ms) */
        double load = std::min(g_bs[sid].prb_used / 100.0, 0.99);
        ue.latency_ms = 1.0 / (1.0 - load + 1e-6) * 2.0 + 0.5;

        g_bs[sid].ue_count++;
        g_bs[sid].total_throughput += ue.throughput_mbps;
        g_bs[sid].interference_w   += res.interference_w;
        bs_ue_tp[sid].push_back(ue.throughput_mbps);
    }

    /* PRB utilization: proportional to UE count */
    for (auto& bs : g_bs) {
        bs.prb_used = (uint32_t)std::min(bs.ue_count * 3u, 100u);
    }

    /* -----------------------------------------------------------------------
     * 4. Apply DRL action: update TX power for SBS
     * --------------------------------------------------------------------- */
    for (auto& bs : g_bs) {
        if (bs.bs_type == "SBS") {
            bs.action       = SelectAction(bs.bs_id);
            bs.tx_power_dbm = ACTION_POWER[bs.action];
        } else {
            bs.action       = 1; /* MBS keeps MED label */
            bs.tx_power_dbm = TX_MBS;
        }
    }

    /* -----------------------------------------------------------------------
     * 5. Write one row per BS
     * --------------------------------------------------------------------- */
    for (const auto& bs : g_bs) {
        double load = (bs.ue_count > 0) ? std::min(bs.prb_used / 100.0, 1.0) : 0.0;
        const EnergyParams& ep = (bs.bs_type == "MBS") ? MBS_ENERGY : SBS_ENERGY;
        double energy_w  = AuerPower(ep, load);
        double ee        = (energy_w > 0.01 && bs.total_throughput > 0.0)
                           ? (bs.total_throughput * 1e6) / energy_w  /* bits/J */
                           : 0.0;

        double interf_dbm = (bs.interference_w > 0.0)
                            ? WToDbm(bs.interference_w)
                            : -140.0;

        double fairness  = JainFairness(bs_ue_tp[bs.bs_id]);

        /* avg/min/max SINR for UEs attached to this BS */
        std::vector<double> sinrs;
        std::vector<double> rsrps;
        std::vector<double> lats;
        for (const auto& ue : g_ue) {
            if (ue.serving_bs == bs.bs_id) {
                sinrs.push_back(ue.sinr_db);
                rsrps.push_back(ue.rsrp_dbm);
                lats.push_back(ue.latency_ms);
            }
        }
        double avg_sinr = sinrs.empty() ? -20.0 :
            std::accumulate(sinrs.begin(), sinrs.end(), 0.0) / sinrs.size();
        double min_sinr = sinrs.empty() ? -20.0 :
            *std::min_element(sinrs.begin(), sinrs.end());
        double max_sinr = sinrs.empty() ? -20.0 :
            *std::max_element(sinrs.begin(), sinrs.end());
        double avg_rsrp = rsrps.empty() ? -120.0 :
            std::accumulate(rsrps.begin(), rsrps.end(), 0.0) / rsrps.size();
        double avg_lat  = lats.empty() ? 5.0 :
            std::accumulate(lats.begin(), lats.end(), 0.0) / lats.size();

        double power_norm = (bs.tx_power_dbm - TX_LOW) / (TX_MBS - TX_LOW);
        double reward = ComputeReward(bs, ee / 1e6, fairness, power_norm);

        g_csv << g_episode         << ","
              << g_time_step       << ","
              << std::fixed << std::setprecision(2) << sim_time << ","
              << bs.bs_id          << ","
              << bs.bs_type        << ","
              << bs.ue_count       << ","
              << std::setprecision(4) << load  << ","
              << std::setprecision(2) << bs.tx_power_dbm << ","
              << bs.action         << ","
              << std::setprecision(4)
              << avg_sinr << "," << min_sinr << "," << max_sinr << ","
              << avg_rsrp          << ","
              << std::setprecision(4) << bs.total_throughput << ","
              << std::setprecision(2) << interf_dbm << ","
              << std::setprecision(4) << energy_w   << ","
              << std::setprecision(2) << (ee / 1e6)  << ","   /* Mbits/J */
              << std::setprecision(4) << avg_lat    << ","
              << std::setprecision(6) << fairness   << ","
              << bs.handover_events << ","
              << std::setprecision(6) << reward     << "\n";

        /* reset handover counter after logging */
        const_cast<BsRecord&>(bs).handover_events = 0;
    }

    g_time_step++;
}

/* ==========================================================================
 * PERIODIC SCHEDULER CALLBACK
 * ========================================================================== */
void ScheduledCollection(NodeContainer ueNodes)
{
    /* Update UE positions from ns-3 mobility */
    for (uint32_t i = 0; i < ueNodes.GetN(); ++i) {
        Ptr<MobilityModel> mob = ueNodes.Get(i)->GetObject<MobilityModel>();
        Vector pos = mob->GetPosition();
        g_ue[i].x = pos.x;
        g_ue[i].y = pos.y;
    }

    double now = Simulator::Now().GetSeconds() - g_sim_offset;
    CollectAndWrite(now);
}

/* ==========================================================================
 * INITIALISE BS TOPOLOGY
 *   MBS  @ (0, 0)
 *   SBS  @ hexagonal ring, radius = SBS_RING_RADIUS
 * ========================================================================== */
void InitBaseStations()
{
    g_bs.clear();

    /* MBS */
    BsRecord mbs;
    mbs.bs_id       = 0;
    mbs.bs_type     = "MBS";
    mbs.x           = 0.0;
    mbs.y           = 0.0;
    mbs.tx_power_dbm = TX_MBS;
    mbs.action      = 1;
    mbs.ue_count    = 0;
    mbs.prb_used    = 0;
    mbs.total_throughput = 0.0;
    mbs.interference_w   = 0.0;
    mbs.handover_events  = 0;
    mbs.ep          = MBS_ENERGY;
    g_bs.push_back(mbs);

    /* SBS hexagonal ring */
    for (uint32_t s = 0; s < NUM_SBS; ++s) {
        double angle = 2.0 * M_PI * s / NUM_SBS;
        BsRecord sbs;
        sbs.bs_id       = s + 1;
        sbs.bs_type     = "SBS";
        sbs.x           = SBS_RING_RADIUS * std::cos(angle);
        sbs.y           = SBS_RING_RADIUS * std::sin(angle);
        sbs.tx_power_dbm = TX_MED;
        sbs.action      = 1;
        sbs.ue_count    = 0;
        sbs.prb_used    = 0;
        sbs.total_throughput = 0.0;
        sbs.interference_w   = 0.0;
        sbs.handover_events  = 0;
        sbs.ep          = SBS_ENERGY;
        g_bs.push_back(sbs);
    }
}

/* ==========================================================================
 * INITIALISE UE RECORDS
 * ========================================================================== */
void InitUEs()
{
    g_ue.clear();
    g_ue.resize(NUM_UES);
    for (uint32_t i = 0; i < NUM_UES; ++i) {
        g_ue[i].ue_id       = i;
        g_ue[i].serving_bs  = 0;
        g_ue[i].sinr_db     = 0.0;
        g_ue[i].rsrp_dbm    = -100.0;
        g_ue[i].throughput_mbps = 0.0;
        g_ue[i].latency_ms  = 5.0;
    }
}

/* ==========================================================================
 * RUN ONE EPISODE
 * ========================================================================== */
void RunEpisode(uint32_t episode)
{
    NS_LOG_INFO("========== Episode " << episode << " ==========");
    g_episode   = episode;
    g_time_step = 0;

    Simulator::Destroy();

    /* -----------------------------------------------------------------------
     * Network setup
     * --------------------------------------------------------------------- */
    NodeContainer enbNodes;
    enbNodes.Create(NUM_ENBS);

    NodeContainer ueNodes;
    ueNodes.Create(NUM_UES);

    /* -----------------------------------------------------------------------
     * Mobility: eNBs fixed, UEs RandomWaypoint
     * --------------------------------------------------------------------- */
    /* eNBs */
    MobilityHelper enbMob;
    enbMob.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    enbMob.Install(enbNodes);

    /* Place eNBs at our predefined positions */
    for (uint32_t i = 0; i < NUM_ENBS; ++i) {
        Ptr<ConstantPositionMobilityModel> mob =
            enbNodes.Get(i)->GetObject<ConstantPositionMobilityModel>();
        mob->SetPosition(Vector(g_bs[i].x, g_bs[i].y, 25.0)); /* height 25m */
    }

    /* UEs: RandomWaypoint inside disc of AREA_RADIUS */
    MobilityHelper ueMob;
    ueMob.SetMobilityModel(
        "ns3::RandomWaypointMobilityModel",
        "Speed",
            StringValue("ns3::UniformRandomVariable[Min=1.0|Max=15.0]"),
        "Pause",
            StringValue("ns3::ConstantRandomVariable[Constant=0.5]"),
        "PositionAllocator",
            StringValue("ns3::RandomDiscPositionAllocator"));

    Ptr<RandomDiscPositionAllocator> posAlloc =
        CreateObject<RandomDiscPositionAllocator>();
    posAlloc->SetX(0.0);
    posAlloc->SetY(0.0);
    posAlloc->SetRho(StringValue(
        "ns3::UniformRandomVariable[Min=0|Max=" +
        std::to_string((int)AREA_RADIUS) + "]"));
    ueMob.SetPositionAllocator(posAlloc);
    ueMob.Install(ueNodes);

    /* Set UE height to 1.5m */
    for (uint32_t i = 0; i < NUM_UES; ++i) {
        Ptr<MobilityModel> mob = ueNodes.Get(i)->GetObject<MobilityModel>();
        Vector pos = mob->GetPosition();
        pos.z = 1.5;
        mob->SetPosition(pos);
    }

    /* -----------------------------------------------------------------------
     * Schedule periodic measurements
     * --------------------------------------------------------------------- */
    double t = 0.0;
    while (t < SIM_DURATION) {
        Simulator::Schedule(
            Seconds(t),
            &ScheduledCollection,
            ueNodes);
        t += CTRL_INTERVAL;
    }

    Simulator::Stop(Seconds(SIM_DURATION));
    Simulator::Run();
}

/* ==========================================================================
 * MAIN
 * ========================================================================== */
int main(int argc, char* argv[])
{
    /* -----------------------------------------------------------------------
     * Command-line options
     * --------------------------------------------------------------------- */
    CommandLine cmd(__FILE__);
    uint32_t seed = 42;
    cmd.AddValue("seed", "Random seed", seed);
    cmd.Parse(argc, argv);

    RngSeedManager::SetSeed(seed);
    RngSeedManager::SetRun(1);
    srand(seed);

    LogComponentEnable("HetNet5GSimulation", LOG_LEVEL_INFO);

    /* -----------------------------------------------------------------------
     * Open CSV
     * --------------------------------------------------------------------- */
    g_csv.open("hetnet_dataset.csv", std::ios::out | std::ios::trunc);
    if (!g_csv.is_open()) {
        NS_LOG_ERROR("Cannot open hetnet_dataset.csv");
        return 1;
    }
    WriteHeader();

    NS_LOG_INFO("==============================================");
    NS_LOG_INFO("  5G HetNet Dataset Generation");
    NS_LOG_INFO("  MBS=" << NUM_MBS << " SBS=" << NUM_SBS
                << " UE=" << NUM_UES);
    NS_LOG_INFO("  Episodes=" << NUM_EPISODES
                << " Duration=" << SIM_DURATION << "s");
    NS_LOG_INFO("  Output: hetnet_dataset.csv");
    NS_LOG_INFO("==============================================");

    /* -----------------------------------------------------------------------
     * Run episodes
     * --------------------------------------------------------------------- */
    for (uint32_t ep = 0; ep < NUM_EPISODES; ++ep) {
        InitBaseStations();
        InitUEs();
        RngSeedManager::SetRun(ep + 1);
        srand(seed + ep * 1000);

        RunEpisode(ep);

        g_sim_offset += SIM_DURATION;

        NS_LOG_INFO("Episode " << ep << " complete. "
                    << "Steps: " << g_time_step);
    }

    g_csv.close();
    Simulator::Destroy();

    /* -----------------------------------------------------------------------
     * Summary
     * --------------------------------------------------------------------- */
    NS_LOG_INFO("==============================================");
    NS_LOG_INFO("  DATASET GENERATION COMPLETE");
    NS_LOG_INFO("  Total rows (approx): "
                << NUM_EPISODES * (uint32_t)(SIM_DURATION / CTRL_INTERVAL) * NUM_ENBS);
    NS_LOG_INFO("  File: hetnet_dataset.csv");
    NS_LOG_INFO("==============================================");

    return 0;
}

#!/usr/bin/env python3
# =============================================================================
# generate_dataset_standalone.py
# Standalone dataset generator that EXACTLY replicates the NS-3 simulation
# physics WITHOUT requiring NS-3 to be installed.
#
# Use this to:
#   1. Test the full pipeline before NS-3 is set up
#   2. Generate larger/smaller datasets quickly
#   3. Sweep over different topology configurations
#
# Physics replicated from hetnet_5g_sim.cc:
#   - Auer 2011 energy model
#   - 3GPP TR36.814 path-loss
#   - Shannon capacity
#   - Jain fairness
#   - M/D/1 latency approximation
# =============================================================================

import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ─── configuration ────────────────────────────────────────────────────────────
CFG = dict(
    num_mbs         = 1,
    num_sbs         = 6,
    num_ues         = 30,
    area_radius_m   = 500.0,
    sbs_ring_m      = 250.0,
    sim_duration_s  = 50.0,
    ctrl_interval_s = 0.5,
    num_episodes    = 4,
    ue_speed_mps    = 3.0,      # m/s average
    seed            = 42,
)

TX_LOW  = 20.0  # dBm
TX_MED  = 30.0
TX_HIGH = 40.0
TX_MBS  = 46.0
ACTION_POWER = [TX_LOW, TX_MED, TX_HIGH]

AUER = {
    "MBS": dict(P0=130.0, delta_p=4.7, Pmax=40.0, Psleep=75.0),
    "SBS": dict(P0=6.8,   delta_p=4.0, Pmax=6.3,  Psleep=2.9),
}

BW_MHZ   = 20.0
NOISE_DBM = -174.0 + 10 * np.log10(BW_MHZ * 1e6) + 9.0  # NF=9dB

OUT_DIR = Path(".")
OUT_DIR.mkdir(exist_ok=True)

# ─── helpers ──────────────────────────────────────────────────────────────────
def dbm2w(dbm): return 10 ** ((dbm - 30) / 10)
def w2dbm(w):   return 10 * np.log10(np.clip(w, 1e-30, None)) + 30

def path_loss_macro(d_m):
    d_m = max(d_m, 1.0)
    return 128.1 + 10 * 3.76 * np.log10(d_m / 1000.0)

def path_loss_sbs(d_m):
    d_m = max(d_m, 1.0)
    return 40.04 + 10 * 2.63 * np.log10(d_m / 100.0)

def auer_power(btype, load):
    p = AUER[btype]
    return p["P0"] + p["delta_p"] * p["Pmax"] * np.clip(load, 0, 1)

def shannon_tp(sinr_db):
    sinr = 10 ** (sinr_db / 10)
    se = min(np.log2(1 + sinr), 18.6)
    return BW_MHZ * se  # Mbps

def jain_fairness(rates):
    if len(rates) == 0: return 1.0
    s1 = sum(rates); s2 = sum(r*r for r in rates)
    return (s1 * s1) / (len(rates) * s2) if s2 > 1e-12 else 1.0

def compute_reward(ee, fairness, power_norm, n_ho):
    ho = min(0.1 * n_ho, 1.0)
    return 0.40 * np.tanh(ee / 10) + 0.25 * fairness - 0.20 * power_norm - 0.15 * ho

# ─── topology ─────────────────────────────────────────────────────────────────
def make_bs_layout():
    bs = [{"bs_id": 0, "bs_type": "MBS", "x": 0.0, "y": 0.0,
            "tx_power_dbm": TX_MBS, "action": 1}]
    for i in range(CFG["num_sbs"]):
        angle = 2 * np.pi * i / CFG["num_sbs"]
        r = CFG["sbs_ring_m"]
        bs.append({
            "bs_id": i + 1, "bs_type": "SBS",
            "x": r * np.cos(angle), "y": r * np.sin(angle),
            "tx_power_dbm": TX_MED, "action": 1,
        })
    return bs

# ─── epsilon-greedy action selection ─────────────────────────────────────────
def select_action(bs, load, eps=0.30):
    if np.random.rand() < eps:
        return np.random.randint(3)
    if load > 0.7: return 2
    if load < 0.2: return 0
    return 1

# ─── UE mobility (Random Waypoint simplified) ─────────────────────────────────
def init_ues(rng):
    angles = rng.uniform(0, 2*np.pi, CFG["num_ues"])
    radii  = CFG["area_radius_m"] * np.sqrt(rng.uniform(0, 1, CFG["num_ues"]))
    x = radii * np.cos(angles)
    y = radii * np.sin(angles)
    vx = rng.uniform(-CFG["ue_speed_mps"], CFG["ue_speed_mps"], CFG["num_ues"])
    vy = rng.uniform(-CFG["ue_speed_mps"], CFG["ue_speed_mps"], CFG["num_ues"])
    return x, y, vx, vy

def move_ues(x, y, vx, vy, dt, rng, bounce=True):
    x = x + vx * dt
    y = y + vy * dt
    R = CFG["area_radius_m"]
    dist = np.sqrt(x**2 + y**2)
    out  = dist > R
    if np.any(out):
        vx[out] = -vx[out] + rng.uniform(-0.5, 0.5, out.sum())
        vy[out] = -vy[out] + rng.uniform(-0.5, 0.5, out.sum())
        scale = R / (dist[out] + 1e-6)
        x[out] = x[out] * scale
        y[out] = y[out] * scale
    return x, y, vx, vy

# ─── main simulation ──────────────────────────────────────────────────────────
def simulate_episode(episode, bs_layout, rng):
    rows = []
    dt   = CFG["ctrl_interval_s"]
    T    = int(CFG["sim_duration_s"] / dt)

    # init UEs
    ux, uy, uvx, uvy = init_ues(rng)
    prev_serving = np.zeros(CFG["num_ues"], dtype=int)  # start on MBS

    # copy BS state
    bs = [dict(b) for b in bs_layout]
    N_bs = len(bs)

    for step in range(T):
        time_s = step * dt
        ux, uy, uvx, uvy = move_ues(ux, uy, uvx, uvy, dt, rng)

        # ── attach UE to best RSRP BS ─────────────────────────────────────
        rsrp_mat = np.zeros((CFG["num_ues"], N_bs))
        for bi, b in enumerate(bs):
            for ui in range(CFG["num_ues"]):
                d = max(np.hypot(ux[ui]-b["x"], uy[ui]-b["y"]), 1.0)
                pl = path_loss_macro(d) if b["bs_type"]=="MBS" else path_loss_sbs(d)
                rsrp_mat[ui, bi] = b["tx_power_dbm"] - pl
        serving = np.argmax(rsrp_mat, axis=1)
        handovers = (serving != prev_serving)
        ho_count_per_bs = np.zeros(N_bs, dtype=int)
        for ui in range(CFG["num_ues"]):
            if handovers[ui]:
                ho_count_per_bs[serving[ui]] += 1

        # ── per-BS statistics ─────────────────────────────────────────────
        for bi, b in enumerate(bs):
            ue_mask = (serving == bi)
            ue_idx  = np.where(ue_mask)[0]
            n_ue    = ue_mask.sum()

            if n_ue == 0:
                sinr_vals = np.array([-20.0])
                tp_vals   = np.array([0.0])
                lat_vals  = np.array([5.0])
            else:
                sinr_vals = []
                tp_vals   = []
                lat_vals  = []
                for ui in ue_idx:
                    # serving signal
                    sig_w = dbm2w(rsrp_mat[ui, bi])
                    # interference
                    interf_w = sum(dbm2w(rsrp_mat[ui, bj])
                                   for bj in range(N_bs) if bj != bi)
                    noise_w  = dbm2w(NOISE_DBM)
                    sinr     = 10 * np.log10(sig_w / (interf_w + noise_w))
                    tp       = shannon_tp(sinr)
                    sinr_vals.append(sinr)
                    tp_vals.append(tp)

                sinr_vals = np.array(sinr_vals)
                tp_vals   = np.array(tp_vals)
                load_frac = min(n_ue * 3 / 100.0, 1.0)
                lat_base  = 1.0 / (1 - load_frac + 1e-6) * 2 + 0.5
                lat_vals  = np.full(n_ue, lat_base)

            prb_util  = min(n_ue * 3 / 100.0, 1.0)
            energy_w  = auer_power(b["bs_type"], prb_util)
            total_tp  = float(tp_vals.sum())
            ee        = (total_tp * 1e6 / energy_w) / 1e6 if energy_w > 0 else 0.0
            fairness  = jain_fairness(tp_vals.tolist())
            interf_w  = sum(dbm2w(b["tx_power_dbm"] -
                            (path_loss_macro(max(np.hypot(b["x"]-bs[bj]["x"],
                                                          b["y"]-bs[bj]["y"]),1))
                             if bs[bj]["bs_type"]=="MBS"
                             else path_loss_sbs(max(np.hypot(b["x"]-bs[bj]["x"],
                                                             b["y"]-bs[bj]["y"]),1))))
                            for bj in range(N_bs) if bj != bi)
            interf_dbm = w2dbm(interf_w) if interf_w > 0 else -140.0
            power_norm = (b["tx_power_dbm"] - TX_LOW) / (TX_MBS - TX_LOW)
            reward     = compute_reward(ee, fairness, power_norm, ho_count_per_bs[bi])

            # action (for next step)
            action = select_action(b, prb_util) if b["bs_type"]=="SBS" else 1
            b["action"]       = int(action)
            b["tx_power_dbm"] = ACTION_POWER[action] if b["bs_type"]=="SBS" else TX_MBS

            rows.append({
                "episode"          : episode,
                "time_step"        : step,
                "time_s"           : round(time_s, 3),
                "bs_id"            : b["bs_id"],
                "bs_type"          : b["bs_type"],
                "ue_count"         : int(n_ue),
                "prb_utilization"  : round(prb_util, 4),
                "tx_power_dbm"     : round(b["tx_power_dbm"], 2),
                "action"           : int(action),
                "avg_sinr_db"      : round(float(sinr_vals.mean()), 4),
                "min_sinr_db"      : round(float(sinr_vals.min()),  4),
                "max_sinr_db"      : round(float(sinr_vals.max()),  4),
                "avg_rsrp_dbm"     : round(float(rsrp_mat[ue_idx, bi].mean())
                                           if n_ue > 0 else -120.0, 4),
                "throughput_mbps"  : round(total_tp, 4),
                "interference_dbm" : round(float(interf_dbm), 2),
                "energy_consumed_w": round(energy_w, 4),
                "energy_efficiency": round(ee, 4),
                "latency_ms"       : round(float(lat_vals.mean()), 4),
                "fairness_index"   : round(fairness, 6),
                "handover_count"   : int(ho_count_per_bs[bi]),
                "reward"           : round(reward, 6),
            })

        prev_serving = serving.copy()

    return rows

# ─── entry point ──────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  5G HetNet Standalone Dataset Generator")
    print(f"  MBS={CFG['num_mbs']}  SBS={CFG['num_sbs']}  UEs={CFG['num_ues']}")
    print(f"  Episodes={CFG['num_episodes']}  Duration={CFG['sim_duration_s']}s")
    print("=" * 60)

    rng = np.random.default_rng(CFG["seed"])
    bs_layout = make_bs_layout()
    all_rows  = []

    for ep in range(CFG["num_episodes"]):
        print(f"  Simulating episode {ep+1}/{CFG['num_episodes']} ...", end=" ", flush=True)
        rows = simulate_episode(ep, bs_layout, rng)
        all_rows.extend(rows)
        print(f"done ({len(rows)} rows)")

    df = pd.DataFrame(all_rows)
    out = OUT_DIR / "hetnet_dataset.csv"
    df.to_csv(out, index=False)

    print(f"\n  Dataset saved: {out}  (shape={df.shape})")
    print(f"  Columns: {list(df.columns)}")

    # save config
    with open(OUT_DIR / "sim_config.json", "w") as f:
        json.dump(CFG, f, indent=2)

    # quick stats
    print("\n  Quick stats:")
    print(f"  Avg throughput  : {df['throughput_mbps'].mean():.3f} Mbps")
    print(f"  Avg SINR        : {df['avg_sinr_db'].mean():.2f} dB")
    print(f"  Avg Energy      : {df['energy_consumed_w'].mean():.3f} W")
    print(f"  Avg EE          : {df['energy_efficiency'].mean():.4f} Mbits/J")
    print(f"  Avg Fairness    : {df['fairness_index'].mean():.4f}")
    print(f"  Avg Latency     : {df['latency_ms'].mean():.3f} ms")
    print(f"  Avg Reward      : {df['reward'].mean():.4f}")
    print("=" * 60)
    print("  Next: python3 process_ns3_output.py && python3 train_mappo.py")

if __name__ == "__main__":
    main()

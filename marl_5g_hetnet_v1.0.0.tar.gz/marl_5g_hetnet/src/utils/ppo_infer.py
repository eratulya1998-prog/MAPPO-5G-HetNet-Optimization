import sys
import torch
import numpy as np
import os
import random

# ================= CONFIG =================
MODEL_PATH = "rl/ppo_model.pth"
STATE_PATH = "logs/state_{}.txt"
ACTION_PATH = "logs/action_{}.txt"

# ================= ACTOR MODEL =================
class Actor(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Linear(3, 64),
            torch.nn.ReLU(),
            torch.nn.Linear(64, 3)
        )

    def forward(self, x):
        return torch.softmax(self.net(x), dim=-1)

# ================= LOAD STATE =================
bs_id = sys.argv[1]

try:
    with open(STATE_PATH.format(bs_id), "r") as f:
        data = f.read().strip().split(",")

    state = np.array([float(x) for x in data])

except:
    print("⚠️ State load error → using default")
    state = np.array([10.0, 50.0, 0.5])  # fallback

# ================= NORMALIZATION =================
state = (state - np.mean(state)) / (np.std(state) + 1e-8)
state = torch.tensor(state, dtype=torch.float32)

# ================= LOAD MODEL =================
model = Actor()
model_loaded = False

if os.path.exists(MODEL_PATH):
    try:
        # 🔥 PyTorch 2.6 fix
        model.load_state_dict(torch.load(MODEL_PATH, weights_only=False))
        model.eval()
        model_loaded = True
        print("✅ Model loaded successfully")
    except Exception as e:
        print("⚠️ Model load error:", e)

# ================= ACTION =================
if model_loaded:
    with torch.no_grad():
        probs = model(state)

        # handle NaN
        if torch.isnan(probs).any():
            print("⚠️ NaN detected → fallback")
            action = random.choice([0, 1, 2])
        else:
            action = torch.argmax(probs).item()
else:
    print("⚠️ Fallback mode activated")
    action = random.choice([0, 1, 2])

# ================= SAVE ACTION =================
with open(ACTION_PATH.format(bs_id), "w") as f:
    f.write(str(action))

# ================= DEBUG OUTPUT =================
mode = ["LOW", "MED", "HIGH"][action]

print("\n===== PPO DECISION =====")
print(f"BS: {bs_id}")
print(f"State: {state.numpy()}")
print(f"Action: {action} → {mode}")
print("========================")

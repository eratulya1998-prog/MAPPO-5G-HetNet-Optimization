
# =========================================================
# FILE: transformer_mappo.py
# OPTIMIZED TRANSFORMER-MAPPO
# =========================================================

import torch
import torch.nn as nn
import torch.nn.functional as F


# =========================================================
# POSITIONAL ENCODING
# =========================================================

class PositionalEncoding(nn.Module):

    def __init__(
        self,
        d_model,
        max_len=512
    ):

        super().__init__()

        pe = torch.zeros(max_len, d_model)

        position = torch.arange(
            0,
            max_len,
            dtype=torch.float
        ).unsqueeze(1)

        div_term = torch.exp(
            torch.arange(
                0,
                d_model,
                2
            ).float()
            *
            (-torch.log(torch.tensor(10000.0)) / d_model)
        )

        pe[:, 0::2] = torch.sin(position * div_term)

        pe[:, 1::2] = torch.cos(position * div_term)

        pe = pe.unsqueeze(0)

        self.register_buffer("pe", pe)

    def forward(self, x):

        seq_len = x.size(1)

        return x + self.pe[:, :seq_len]


# =========================================================
# TRANSFORMER BLOCK
# =========================================================

class TransformerBlock(nn.Module):

    def __init__(
        self,
        embed_dim=128,
        num_heads=4,
        dropout=0.1
    ):

        super().__init__()

        self.attention = nn.MultiheadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )

        self.norm1 = nn.LayerNorm(embed_dim)

        self.norm2 = nn.LayerNorm(embed_dim)

        self.feed_forward = nn.Sequential(

            nn.Linear(embed_dim, 256),

            nn.GELU(),

            nn.Dropout(dropout),

            nn.Linear(256, embed_dim)

        )

        self.dropout = nn.Dropout(dropout)

    def forward(self, x):

        attn_out, attn_weights = self.attention(
            x,
            x,
            x,
            need_weights=True
        )

        x = self.norm1(
            x + self.dropout(attn_out)
        )

        ff_out = self.feed_forward(x)

        x = self.norm2(
            x + self.dropout(ff_out)
        )

        return x, attn_weights


# =========================================================
# RESEARCH-GRADE TRANSFORMER MAPPO
# =========================================================

class OptimizedTransformerMAPPO(nn.Module):

    def __init__(
        self,
        state_dim,
        action_dim,
        embed_dim=128,
        num_heads=4,
        num_layers=3,
        dropout=0.1
    ):

        super().__init__()

        self.state_dim = state_dim

        self.action_dim = action_dim

        self.embed_dim = embed_dim

        # =====================================================
        # INPUT ENCODER
        # =====================================================

        self.encoder = nn.Sequential(

            nn.Linear(state_dim, embed_dim),

            nn.LayerNorm(embed_dim),

            nn.GELU(),

            nn.Dropout(dropout),

            nn.Linear(embed_dim, embed_dim),

            nn.GELU()

        )

        # =====================================================
        # POSITIONAL ENCODING
        # =====================================================

        self.position = PositionalEncoding(
            embed_dim
        )

        # =====================================================
        # TRANSFORMER STACK
        # =====================================================

        self.transformer_layers = nn.ModuleList([

            TransformerBlock(
                embed_dim=embed_dim,
                num_heads=num_heads,
                dropout=dropout
            )

            for _ in range(num_layers)

        ])

        # =====================================================
        # SHARED LATENT SPACE
        # =====================================================

        self.shared = nn.Sequential(

            nn.Linear(embed_dim, embed_dim),

            nn.LayerNorm(embed_dim),

            nn.GELU(),

            nn.Dropout(dropout)

        )

        # =====================================================
        # ACTOR NETWORK
        # =====================================================

        self.actor = nn.Sequential(

            nn.Linear(embed_dim, 128),

            nn.GELU(),

            nn.Dropout(dropout),

            nn.Linear(128, 64),

            nn.GELU(),

            nn.Linear(64, action_dim)

        )

        # =====================================================
        # CRITIC NETWORK
        # =====================================================

        self.critic = nn.Sequential(

            nn.Linear(embed_dim, 128),

            nn.GELU(),

            nn.Dropout(dropout),

            nn.Linear(128, 64),

            nn.GELU(),

            nn.Linear(64, 1)

        )

        # =====================================================
        # WEIGHT INIT
        # =====================================================

        self.apply(self._init_weights)

    # =========================================================
    # WEIGHT INITIALIZATION
    # =========================================================

    def _init_weights(self, module):

        if isinstance(module, nn.Linear):

            nn.init.xavier_uniform_(module.weight)

            if module.bias is not None:

                nn.init.constant_(module.bias, 0)

    # =========================================================
    # FORWARD
    # =========================================================

    def forward(self, states):

        # =====================================================
        # ENCODE STATES
        # =====================================================

        x = self.encoder(states)

        # =====================================================
        # POSITIONAL INFORMATION
        # =====================================================

        x = self.position(x)

        # =====================================================
        # TRANSFORMER PROCESSING
        # =====================================================

        attention_maps = []

        for layer in self.transformer_layers:

            x, attn = layer(x)

            attention_maps.append(attn)

        # =====================================================
        # SHARED FEATURES
        # =====================================================

        x = self.shared(x)

        # =====================================================
        # POLICY LOGITS
        # =====================================================

        logits = self.actor(x)

        # =====================================================
        # STATE VALUE
        # =====================================================

        values = self.critic(x)

        return logits, values, attention_maps

    # =========================================================
    # ACTION SELECTION
    # =========================================================

    def act(self, states):

        logits, values, _ = self.forward(states)

        probs = F.softmax(
            logits,
            dim=-1
        )

        dist = torch.distributions.Categorical(probs)

        actions = dist.sample()

        log_probs = dist.log_prob(actions)

        entropy = dist.entropy()

        return (
            actions,
            log_probs,
            values,
            entropy
        )

    # =========================================================
    # EVALUATE ACTIONS
    # =========================================================

    def evaluate_actions(
        self,
        states,
        actions
    ):

        logits, values, attention_maps = self.forward(states)

        probs = F.softmax(
            logits,
            dim=-1
        )

        dist = torch.distributions.Categorical(probs)

        log_probs = dist.log_prob(actions)

        entropy = dist.entropy().mean()

        return (
            log_probs,
            values,
            entropy,
            attention_maps
        )


# =========================================================
# ACTION HELPER
# =========================================================

@torch.no_grad()
def select_action(
    model,
    states,
    device
):

    model.eval()

    states = torch.FloatTensor(states).to(device)

    if len(states.shape) == 2:

        states = states.unsqueeze(1)

    actions, log_probs, values, entropy = model.act(states)

    return {
        "actions": actions.cpu().numpy(),
        "log_probs": log_probs.cpu(),
        "values": values.cpu(),
        "entropy": entropy.cpu()
    }


# =========================================================
# MODEL INFO
# =========================================================

def print_model_info(model):

    total_params = sum(
        p.numel()
        for p in model.parameters()
    )

    trainable_params = sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )

    print("=" * 60)
    print("OPTIMIZED TRANSFORMER-MAPPO")
    print("=" * 60)
    print(f"Total Parameters: {total_params:,}")
    print(f"Trainable Parameters: {trainable_params:,}")
    print("=" * 60)


# =========================================================
# TEST BLOCK
# =========================================================

if __name__ == "__main__":

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    model = OptimizedTransformerMAPPO(
        state_dim=14,
        action_dim=3
    ).to(device)

    print_model_info(model)

    dummy_input = torch.randn(
        32,
        1,
        14
    ).to(device)

    logits, values, attn = model(dummy_input)

    print("Logits Shape:", logits.shape)

    print("Values Shape:", values.shape)

    print("Forward Pass Successful")

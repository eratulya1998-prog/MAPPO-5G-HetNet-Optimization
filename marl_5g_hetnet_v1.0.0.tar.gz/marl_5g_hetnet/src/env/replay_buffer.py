# =========================================================
# FILE: replay_buffer.py
# RESEARCH-GRADE OPTIMIZED REPLAY BUFFER
# =========================================================

import numpy as np
import torch


class OptimizedReplayBuffer:

    def __init__(

        self,

        capacity,

        state_dim

    ):

        self.capacity = capacity

        self.ptr = 0

        self.size = 0

        # =================================================
        # PREALLOCATED MEMORY
        # =================================================

        self.states = np.zeros(

            (

                capacity,

                state_dim

            ),

            dtype=np.float32

        )

        self.actions = np.zeros(

            capacity,

            dtype=np.int64

        )

        self.rewards = np.zeros(

            capacity,

            dtype=np.float32

        )

        self.next_states = np.zeros(

            (

                capacity,

                state_dim

            ),

            dtype=np.float32

        )

        self.dones = np.zeros(

            capacity,

            dtype=np.float32

        )

    # =====================================================
    # STORE TRANSITION
    # =====================================================

    def store(

        self,

        state,

        action,

        reward,

        next_state,

        done

    ):

        self.states[self.ptr] = state

        self.actions[self.ptr] = action

        self.rewards[self.ptr] = reward

        self.next_states[self.ptr] = next_state

        self.dones[self.ptr] = done

        self.ptr = (

            self.ptr + 1

        ) % self.capacity

        self.size = min(

            self.size + 1,

            self.capacity

        )

    # =====================================================
    # SAMPLE BATCH
    # =====================================================

    def sample(

        self,

        batch_size,

        device

    ):

        indices = np.random.choice(

            self.size,

            batch_size,

            replace=False

        )

        states = torch.FloatTensor(

            self.states[indices]

        ).to(device)

        actions = torch.LongTensor(

            self.actions[indices]

        ).to(device)

        rewards = torch.FloatTensor(

            self.rewards[indices]

        ).to(device)

        next_states = torch.FloatTensor(

            self.next_states[indices]

        ).to(device)

        dones = torch.FloatTensor(

            self.dones[indices]

        ).to(device)

        return (

            states,

            actions,

            rewards,

            next_states,

            dones

        )

    # =====================================================
    # CLEAR BUFFER
    # =====================================================

    def clear(self):

        self.ptr = 0

        self.size = 0

    # =====================================================
    # BUFFER SIZE
    # =====================================================

    def __len__(self):

        return self.size

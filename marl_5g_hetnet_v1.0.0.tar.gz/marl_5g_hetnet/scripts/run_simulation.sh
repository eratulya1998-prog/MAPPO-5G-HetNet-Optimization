#!/usr/bin/env bash
# =============================================================================
# run_simulation.sh
# Build & run the 5G HetNet NS-3 dataset generator on WSL Ubuntu
# =============================================================================
# USAGE:
#   chmod +x run_simulation.sh
#   ./run_simulation.sh [/path/to/ns3-root]
#
# If no path given, the script looks for ns-3 in common locations:
#   ~/ns-allinone-3.*/ns-3.*   or   ~/ns-3-dev
# =============================================================================

set -euo pipefail

# ─── colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ─── banner ───────────────────────────────────────────────────────────────────
echo -e "${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   5G HetNet NS-3 Dataset Generator – MA-DRL Research        ║"
echo "║   MBS=1  SBS=6  UEs=30  Episodes=4  Duration=50s each       ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ─── locate ns-3 root ─────────────────────────────────────────────────────────
NS3_ROOT=""
if [[ $# -ge 1 ]]; then
    NS3_ROOT="$1"
elif ls -d ~/ns-allinone-3.*/ns-3.* 2>/dev/null | head -1 | grep -q .; then
    NS3_ROOT=$(ls -d ~/ns-allinone-3.*/ns-3.* 2>/dev/null | sort -V | tail -1)
elif [[ -d ~/ns-3-dev ]]; then
    NS3_ROOT=~/ns-3-dev
elif [[ -d ~/ns3 ]]; then
    NS3_ROOT=~/ns3
fi

if [[ -z "$NS3_ROOT" || ! -d "$NS3_ROOT" ]]; then
    warn "ns-3 root not found automatically."
    echo ""
    echo "Please install ns-3 first:"
    echo "  sudo apt update && sudo apt install -y build-essential cmake python3 python3-pip g++ git"
    echo "  cd ~ && wget https://www.nsnam.org/releases/ns-allinone-3.42.tar.bz2"
    echo "  tar xjf ns-allinone-3.42.tar.bz2"
    echo "  cd ns-allinone-3.42 && python3 build.py --enable-examples"
    echo ""
    echo "Then re-run:  ./run_simulation.sh ~/ns-allinone-3.42/ns-3.42"
    exit 1
fi

info "NS-3 root: ${NS3_ROOT}"

# ─── check ns3 tool ───────────────────────────────────────────────────────────
NS3_TOOL="${NS3_ROOT}/ns3"
[[ -x "$NS3_TOOL" ]] || error "ns3 tool not found at ${NS3_TOOL}. Is ns-3 built?"

# ─── install python deps ──────────────────────────────────────────────────────
info "Installing Python dependencies..."
pip3 install numpy pandas matplotlib scikit-learn torch tqdm --quiet \
    || warn "pip3 install had issues – continuing"

# ─── copy simulation script ───────────────────────────────────────────────────
SCRATCH="${NS3_ROOT}/scratch"
mkdir -p "$SCRATCH"
SCRIPT_SRC="$(dirname "$0")/hetnet_5g_sim.cc"

if [[ ! -f "$SCRIPT_SRC" ]]; then
    # fallback: look in current dir
    SCRIPT_SRC="hetnet_5g_sim.cc"
fi
[[ -f "$SCRIPT_SRC" ]] || error "hetnet_5g_sim.cc not found next to this script."

info "Copying simulation to scratch/..."
cp "$SCRIPT_SRC" "${SCRATCH}/hetnet_5g_sim.cc"
success "Copied → ${SCRATCH}/hetnet_5g_sim.cc"

# ─── configure & build ────────────────────────────────────────────────────────
info "Configuring ns-3 (optimized build)..."
cd "$NS3_ROOT"

"$NS3_TOOL" configure \
    --build-profile=optimized \
    --disable-examples \
    --disable-tests \
    2>&1 | tail -5

info "Building scratch/hetnet_5g_sim ..."
"$NS3_TOOL" build scratch/hetnet_5g_sim 2>&1 | tail -10
success "Build complete."

# ─── create output dir ────────────────────────────────────────────────────────
OUT_DIR="$(dirname "$0")"
mkdir -p "${OUT_DIR}/results"

# ─── run simulation ───────────────────────────────────────────────────────────
info "Running simulation (4 episodes × 50s = 200s simulated time)..."
echo "   This may take 1–3 minutes on a modern PC."
echo ""

"$NS3_TOOL" run "hetnet_5g_sim --seed=42" 2>&1 | grep -E "Episode|COMPLETE|steps|Step" || true

# ─── move CSV ────────────────────────────────────────────────────────────────-
if [[ -f "hetnet_dataset.csv" ]]; then
    mv hetnet_dataset.csv "${OUT_DIR}/hetnet_dataset.csv"
    ROW_COUNT=$(wc -l < "${OUT_DIR}/hetnet_dataset.csv")
    success "Dataset saved → ${OUT_DIR}/hetnet_dataset.csv  (${ROW_COUNT} rows)"
else
    error "hetnet_dataset.csv not generated. Check ns-3 output above."
fi

cd "$OUT_DIR"

# ─── post-process ─────────────────────────────────────────────────────────────
info "Post-processing dataset..."
python3 process_ns3_output.py && success "Post-processing done."

# ─── plot results ─────────────────────────────────────────────────────────────
info "Generating plots..."
python3 plot_results.py 2>/dev/null && success "Plots saved → results/" || warn "plot_results.py had issues"

# ─── train MAPPO ──────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}Dataset ready. To train the Transformer-MAPPO agent:${NC}"
echo "   python3 train_mappo.py"
echo ""
echo -e "${BOLD}To run inference (PPO):${NC}"
echo "   python3 ppo_infer.py 0"
echo ""
success "All done! 🎉"

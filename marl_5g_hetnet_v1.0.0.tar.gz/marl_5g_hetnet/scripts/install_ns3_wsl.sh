#!/usr/bin/env bash
# =============================================================================
# install_ns3_wsl.sh
# One-shot NS-3 installer for WSL Ubuntu (tested on Ubuntu 20.04 / 22.04)
# =============================================================================
# USAGE:
#   chmod +x install_ns3_wsl.sh
#   ./install_ns3_wsl.sh
# Takes ~15-25 min depending on network speed.
# =============================================================================

set -euo pipefail

NS3_VERSION="3.42"
INSTALL_DIR="$HOME"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo -e "${BOLD}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   NS-3 ${NS3_VERSION} Installer for WSL Ubuntu                    ║"
echo "║   5G HetNet MA-DRL Research Setup                       ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ─── WSL check ────────────────────────────────────────────────────────────────
if grep -qi microsoft /proc/version 2>/dev/null; then
    info "WSL environment detected ✓"
else
    warn "Not on WSL – continuing anyway"
fi

# ─── system packages ──────────────────────────────────────────────────────────
info "Updating apt and installing build dependencies..."
sudo apt update -qq
sudo apt install -y \
    build-essential cmake g++ python3 python3-pip python3-dev \
    git wget tar bzip2 \
    libxml2 libxml2-dev \
    libgsl-dev \
    libsqlite3-dev \
    libboost-all-dev \
    qt5-default 2>/dev/null || true \
    tcpdump wireshark-common 2>/dev/null || true
success "System packages installed."

# ─── Python packages ──────────────────────────────────────────────────────────
info "Installing Python packages..."
pip3 install --upgrade pip --quiet
pip3 install numpy pandas matplotlib scikit-learn torch tqdm --quiet
success "Python packages installed."

# ─── Download ns-3 ───────────────────────────────────────────────────────────
TARBALL="ns-allinone-${NS3_VERSION}.tar.bz2"
NS3_DIR="${INSTALL_DIR}/ns-allinone-${NS3_VERSION}/ns-${NS3_VERSION}"

if [[ -d "$NS3_DIR" ]]; then
    warn "NS-3 directory already exists at ${NS3_DIR}, skipping download."
else
    info "Downloading ns-${NS3_VERSION}..."
    cd "$INSTALL_DIR"
    wget -q --show-progress \
        "https://www.nsnam.org/releases/${TARBALL}" \
        -O "${TARBALL}"
    success "Download complete."

    info "Extracting..."
    tar xjf "${TARBALL}"
    rm -f "${TARBALL}"
    success "Extracted to ${INSTALL_DIR}/ns-allinone-${NS3_VERSION}/"
fi

# ─── Configure & build ns-3 ──────────────────────────────────────────────────
info "Configuring ns-3 (optimized, examples off, tests off)..."
cd "$NS3_DIR"

./ns3 configure \
    --build-profile=optimized \
    --disable-examples \
    --disable-tests \
    --enable-modules="core,network,internet,mobility,lte,buildings,applications,flow-monitor,point-to-point" \
    2>&1 | tail -15

info "Building (this takes ~10-20 min)..."
./ns3 build 2>&1 | tail -5
success "NS-3 built successfully."

# ─── Copy simulation files ────────────────────────────────────────────────────
SCRATCH="${NS3_DIR}/scratch"
mkdir -p "$SCRATCH"
PROJ_DIR="$(dirname "$(realpath "$0")")"

info "Copying simulation script to scratch/ ..."
cp "${PROJ_DIR}/hetnet_5g_sim.cc" "${SCRATCH}/hetnet_5g_sim.cc"
success "Copied hetnet_5g_sim.cc → ${SCRATCH}/"

# ─── Build simulation ─────────────────────────────────────────────────────────
info "Building simulation..."
./ns3 build scratch/hetnet_5g_sim
success "hetnet_5g_sim built."

# ─── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}Installation complete!${NC}"
echo ""
echo -e "${BOLD}NS-3 root:${NC} ${NS3_DIR}"
echo ""
echo -e "${BOLD}Next steps:${NC}"
echo "  cd ${PROJ_DIR}"
echo "  ./run_simulation.sh ${NS3_DIR}     # generate dataset"
echo "  python3 process_ns3_output.py      # post-process"
echo "  python3 train_mappo.py             # train MAPPO"
echo "  python3 plot_results.py            # visualise"
echo ""
echo -e "${BOLD}Manual run:${NC}"
echo "  cd ${NS3_DIR}"
echo "  ./ns3 run \"hetnet_5g_sim --seed=42\""
echo "  mv hetnet_dataset.csv ${PROJ_DIR}/"

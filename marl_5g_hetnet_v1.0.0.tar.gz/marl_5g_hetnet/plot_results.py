# =============================================================================
# plot_results.py  (updated for NS-3 hetnet_dataset)
# Research-grade visualisation of 5G HetNet simulation results
# =============================================================================

import os
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pandas as pd

matplotlib.rcParams.update({
    "font.family"     : "DejaVu Sans",
    "font.size"       : 11,
    "axes.titlesize"  : 13,
    "axes.labelsize"  : 12,
    "legend.fontsize" : 10,
    "figure.dpi"      : 120,
    "axes.grid"       : True,
    "grid.alpha"      : 0.3,
    "lines.linewidth" : 1.8,
})

RESULTS = Path("results")
RESULTS.mkdir(exist_ok=True)

# ─── load dataset ─────────────────────────────────────────────────────────────
CSV = RESULTS / "hetnet_processed.csv"
if not CSV.exists():
    CSV = Path("hetnet_dataset.csv")
if not CSV.exists():
    sys.exit("[ERROR] No dataset found. Run process_ns3_output.py first.")

print(f"Loading {CSV} ...")
df = pd.read_csv(CSV)
print(f"  Shape: {df.shape}")

def ma(arr, w=10):
    return np.convolve(arr, np.ones(w) / w, mode="valid")

# =============================================================================
# 1.  NETWORK-WIDE THROUGHPUT
# =============================================================================
ts = df.groupby("time_step")["throughput_mbps"].sum().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(ts["time_step"], ts["throughput_mbps"], alpha=0.35, color="steelblue", label="Raw")
ax.plot(ma(ts["throughput_mbps"].values),       color="steelblue", lw=2.2, label="MA-10")
ax.set_xlabel("Time Step"); ax.set_ylabel("Total Throughput (Mbps)")
ax.set_title("Network-Wide Throughput Over Time")
ax.legend()
fig.tight_layout()
fig.savefig(RESULTS / "throughput_plot.png")
plt.close(fig)

# =============================================================================
# 2.  ENERGY EFFICIENCY
# =============================================================================
ts_ee = df.groupby("time_step")["energy_efficiency"].mean().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(ts_ee["time_step"], ts_ee["energy_efficiency"], alpha=0.35, color="forestgreen")
ax.plot(ma(ts_ee["energy_efficiency"].values), color="forestgreen", lw=2.2)
ax.set_xlabel("Time Step"); ax.set_ylabel("Energy Efficiency (Mbits/J)")
ax.set_title("Network Energy Efficiency (Auer 2011 Model)")
fig.tight_layout()
fig.savefig(RESULTS / "energy_efficiency_plot.png")
plt.close(fig)

# =============================================================================
# 3.  JAIN FAIRNESS INDEX
# =============================================================================
ts_fi = df.groupby("time_step")["fairness_index"].mean().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(ts_fi["time_step"], ts_fi["fairness_index"], alpha=0.35, color="darkorange")
ax.plot(ma(ts_fi["fairness_index"].values), color="darkorange", lw=2.2)
ax.set_ylim(0, 1.05)
ax.set_xlabel("Time Step"); ax.set_ylabel("Jain Fairness Index")
ax.set_title("User Fairness (Jain's Index)")
fig.tight_layout()
fig.savefig(RESULTS / "fairness_plot.png")
plt.close(fig)

# =============================================================================
# 4.  LATENCY
# =============================================================================
ts_lat = df.groupby("time_step")["latency_ms"].mean().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(ts_lat["time_step"], ts_lat["latency_ms"], alpha=0.35, color="crimson")
ax.plot(ma(ts_lat["latency_ms"].values), color="crimson", lw=2.2)
ax.set_xlabel("Time Step"); ax.set_ylabel("Latency (ms)")
ax.set_title("Average UE Latency Reduction")
fig.tight_layout()
fig.savefig(RESULTS / "latency_plot.png")
plt.close(fig)

# =============================================================================
# 5.  RL REWARD
# =============================================================================
ts_rw = df.groupby("time_step")["reward"].mean().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(ts_rw["time_step"], ts_rw["reward"], alpha=0.35, color="purple")
ax.plot(ma(ts_rw["reward"].values), color="purple", lw=2.2)
ax.set_xlabel("Time Step"); ax.set_ylabel("Reward")
ax.set_title("DRL Agent Reward Convergence")
fig.tight_layout()
fig.savefig(RESULTS / "reward_plot.png")
plt.close(fig)

# =============================================================================
# 6.  TX POWER DISTRIBUTION (MBS vs SBS)
# =============================================================================
fig, ax = plt.subplots(figsize=(9, 4))
for btype, color in [("MBS", "royalblue"), ("SBS", "tomato")]:
    sub = df[df["bs_type"] == btype]["tx_power_dbm"]
    ax.hist(sub, bins=10, alpha=0.65, label=btype, color=color, edgecolor="white")
ax.set_xlabel("TX Power (dBm)"); ax.set_ylabel("Frequency")
ax.set_title("Transmit Power Allocation Distribution")
ax.legend()
fig.tight_layout()
fig.savefig(RESULTS / "power_distribution.png")
plt.close(fig)

# =============================================================================
# 7.  HANDOVER STABILITY
# =============================================================================
ts_ho = df.groupby("time_step")["handover_count"].sum().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.bar(ts_ho["time_step"], ts_ho["handover_count"],
       color="slateblue", alpha=0.75, width=0.9)
ax.set_xlabel("Time Step"); ax.set_ylabel("Handover Events")
ax.set_title("Network-Wide Handover Events")
fig.tight_layout()
fig.savefig(RESULTS / "handover_stability.png")
plt.close(fig)

# =============================================================================
# 8.  INTERFERENCE
# =============================================================================
ts_int = df.groupby("time_step")["interference_dbm"].mean().reset_index()
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(ts_int["time_step"], ts_int["interference_dbm"], alpha=0.35, color="saddlebrown")
ax.plot(ma(ts_int["interference_dbm"].values), color="saddlebrown", lw=2.2)
ax.set_xlabel("Time Step"); ax.set_ylabel("Interference (dBm)")
ax.set_title("Aggregate Co-channel Interference")
fig.tight_layout()
fig.savefig(RESULTS / "interference_plot.png")
plt.close(fig)

# =============================================================================
# 9.  ACTION DISTRIBUTION
# =============================================================================
fig, ax = plt.subplots(figsize=(7, 4))
sbs_df = df[df["bs_type"] == "SBS"]
counts = sbs_df["action"].value_counts().sort_index()
colors = ["#4CAF50", "#FFC107", "#F44336"]
labels = ["LOW (20 dBm)", "MED (30 dBm)", "HIGH (40 dBm)"]
bars = ax.bar([labels[i] for i in counts.index], counts.values,
              color=[colors[i] for i in counts.index], edgecolor="white", linewidth=0.8)
for bar, val in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
            str(val), ha="center", va="bottom", fontsize=10)
ax.set_ylabel("Count"); ax.set_title("DRL Power Action Distribution (SBS)")
fig.tight_layout()
fig.savefig(RESULTS / "action_distribution.png")
plt.close(fig)

# =============================================================================
# 10.  SINR CDF (per BS type)
# =============================================================================
fig, ax = plt.subplots(figsize=(8, 5))
for btype, color, ls in [("MBS", "royalblue", "-"), ("SBS", "tomato", "--")]:
    vals = df[df["bs_type"] == btype]["avg_sinr_db"].dropna().sort_values()
    cdf  = np.arange(1, len(vals) + 1) / len(vals)
    ax.plot(vals, cdf, color=color, ls=ls, label=btype, lw=2)
ax.set_xlabel("SINR (dB)"); ax.set_ylabel("CDF")
ax.set_title("SINR Cumulative Distribution Function")
ax.legend()
fig.tight_layout()
fig.savefig(RESULTS / "sinr_cdf.png")
plt.close(fig)

# =============================================================================
# 11.  PER-EPISODE LEARNING CURVE
# =============================================================================
ep_rw = df.groupby("episode")["reward"].mean().reset_index()
fig, ax = plt.subplots(figsize=(8, 4))
ax.bar(ep_rw["episode"], ep_rw["reward"], color="mediumslateblue", edgecolor="white")
ax.set_xlabel("Episode"); ax.set_ylabel("Mean Reward")
ax.set_title("Per-Episode Mean DRL Reward")
fig.tight_layout()
fig.savefig(RESULTS / "episode_rewards.png")
plt.close(fig)

# =============================================================================
# 12.  TRAINING LOSS / REWARD HISTORY  (from numpy files)
# =============================================================================
for fname, ylabel, title, color in [
    ("loss_history.npy",   "Loss",   "MAPPO Training Loss",   "darkorange"),
    ("reward_history.npy", "Reward", "MAPPO Training Reward", "teal"),
]:
    path = RESULTS / fname
    if path.exists():
        data = np.load(path)
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(data, color=color, lw=2)
        ax.set_xlabel("Epoch"); ax.set_ylabel(ylabel)
        ax.set_title(title)
        fig.tight_layout()
        fig.savefig(RESULTS / fname.replace(".npy", ".png"))
        plt.close(fig)
        print(f"  Saved: {fname.replace('.npy', '.png')}")

# =============================================================================
# 13.  COMPREHENSIVE DASHBOARD (6-panel)
# =============================================================================
fig = plt.figure(figsize=(18, 11))
fig.suptitle(
    "MA-DRL 5G HetNet Energy-Efficient Optimisation — NS-3 Simulation Results",
    fontsize=15, fontweight="bold", y=0.98
)
gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)

panels = [
    (ts["time_step"],     ts["throughput_mbps"],         "Throughput (Mbps)",     "steelblue"),
    (ts_ee["time_step"],  ts_ee["energy_efficiency"],    "Energy Efficiency",      "forestgreen"),
    (ts_fi["time_step"],  ts_fi["fairness_index"],       "Jain Fairness",          "darkorange"),
    (ts_lat["time_step"], ts_lat["latency_ms"],          "Latency (ms)",           "crimson"),
    (ts_rw["time_step"],  ts_rw["reward"],               "RL Reward",              "purple"),
    (ts_int["time_step"], ts_int["interference_dbm"],    "Interference (dBm)",     "saddlebrown"),
    (ts_ho["time_step"],  ts_ho["handover_count"],       "Handover Events",        "slateblue"),
    # SINR panel
    None,
    # Action dist panel
    None,
]

axs = [fig.add_subplot(gs[i // 3, i % 3]) for i in range(9)]

for i, panel in enumerate(panels[:7]):
    x, y_raw, ylabel, color = panel
    y = np.array(y_raw)
    axs[i].plot(x, y, alpha=0.3, color=color)
    if len(y) > 10:
        axs[i].plot(x.values[9:] if hasattr(x, 'values') else x[9:],
                    ma(y), color=color, lw=2)
    axs[i].set_ylabel(ylabel, fontsize=9)
    axs[i].set_xlabel("Step", fontsize=8)
    axs[i].tick_params(labelsize=8)

# SINR CDF in panel 7
for btype, color, ls in [("MBS", "royalblue", "-"), ("SBS", "tomato", "--")]:
    vals = df[df["bs_type"] == btype]["avg_sinr_db"].dropna().sort_values()
    cdf  = np.arange(1, len(vals) + 1) / len(vals)
    axs[7].plot(vals, cdf, color=color, ls=ls, label=btype, lw=1.5)
axs[7].set_xlabel("SINR (dB)", fontsize=8)
axs[7].set_ylabel("CDF", fontsize=9)
axs[7].legend(fontsize=7)
axs[7].set_title("SINR CDF", fontsize=10)

# Action distribution in panel 8
if len(sbs_df) > 0:
    action_counts = sbs_df["action"].value_counts().sort_index()
    colors8 = ["#4CAF50", "#FFC107", "#F44336"][:len(action_counts)]
    labels8 = [["L","M","H"][int(a)] for a in action_counts.index]
    axs[8].bar(labels8, action_counts.values, color=colors8, edgecolor="white")
    axs[8].set_xlabel("Action", fontsize=8)
    axs[8].set_ylabel("Count", fontsize=9)
    axs[8].set_title("Action Distribution", fontsize=10)

fig.savefig(RESULTS / "dashboard.png", bbox_inches="tight")
plt.close(fig)
print("  Saved: dashboard.png")

# =============================================================================
# SUMMARY
# =============================================================================
print("\n" + "=" * 60)
print("  Research-Grade Graphs Generated")
print("  Output directory : results/")
print("=" * 60)
print(f"  Throughput      : {df['throughput_mbps'].mean():.3f} Mbps (avg)")
print(f"  SINR            : {df['avg_sinr_db'].mean():.2f} dB  (avg)")
print(f"  Energy Eff.     : {df['energy_efficiency'].mean():.4f} Mbits/J")
print(f"  Fairness        : {df['fairness_index'].mean():.4f}")
print(f"  Latency         : {df['latency_ms'].mean():.3f} ms")
print(f"  Avg Reward      : {df['reward'].mean():.4f}")
print("=" * 60)

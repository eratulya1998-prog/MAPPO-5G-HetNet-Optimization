# MA-DRL 5G HetNet: Multi-Agent Deep Reinforcement Learning for Adaptive Energy-Efficient Optimization in 5G Heterogeneous Networks

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python)](https://python.org)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0%2B-EE4C2C?logo=pytorch)](https://pytorch.org)
[![NS-3](https://img.shields.io/badge/NS--3-3.42-green)](https://nsnam.org)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

> **Research implementation** of a Transformer-based Multi-Agent Proximal Policy Optimisation (MAPPO) framework for joint power control and energy efficiency optimisation in 5G heterogeneous networks, with dataset generation via NS-3 discrete-event simulation.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Topology](#topology)
- [Energy Model](#energy-model)
- [Reward Function](#reward-function)
- [Dataset Columns](#dataset-columns)
- [Quick Start](#quick-start)
- [NS-3 Setup (WSL Ubuntu)](#ns-3-setup-wsl-ubuntu)
- [Training](#training)
- [Results](#results)
- [Project Structure](#project-structure)
- [Citation](#citation)

---

## Overview

This framework addresses the problem of **adaptive energy-efficient power control** in 5G HetNets, where multiple base stations (BS) must cooperate to maximise network throughput while minimising energy consumption and maintaining fairness across user equipment (UE).

**Key contributions:**
- NS-3 C++ simulation generating realistic 5G HetNet datasets (SINR, throughput, energy, handover, latency)
- Transformer-MAPPO agent with multi-head self-attention over BS state sequences
- Auer 2011 (EARTH project) energy model for both Macro BS and Small BS
- 3GPP TR36.814 path-loss model with per-cell SINR computation
- Jain fairness index optimisation alongside energy efficiency

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    NS-3 SIMULATION LAYER                     │
│  hetnet_5g_sim.cc → hetnet_dataset.csv                       │
│  1 MBS + 6 SBS + 30 UEs · RandomWaypoint · 4 episodes       │
└────────────────────────┬────────────────────────────────────-┘
                         │ 21 features × 2800 rows
┌────────────────────────▼────────────────────────────────────-┐
│                  POST-PROCESSING LAYER                        │
│  process_ns3_output.py                                        │
│  → GAE advantage · normalisation · train/val/test split       │
│  → states.npy [T, 7, 7]  actions.npy  rewards.npy            │
└────────────────────────┬─────────────────────────────────────┘
                         │
┌────────────────────────▼─────────────────────────────────────┐
│              TRANSFORMER-MAPPO AGENT                          │
│                                                               │
│  State [B,1,D] ──► Linear Encoder ──► Positional Encoding    │
│                         │                                     │
│              ┌──────────▼──────────┐                         │
│              │  3× TransformerBlock │  (4 heads, GELU, LN)   │
│              └──────────┬──────────┘                         │
│                         │ Shared latent                       │
│              ┌──────────┴──────────┐                         │
│           Actor                 Critic                        │
│       (policy logits)        (state value)                    │
│              │                                                │
│           PPO clip · GAE · Entropy bonus · Value loss         │
└──────────────────────────────────────────────────────────────┘
```

---

## Topology

```
                        MBS (0,0)
                         ●  46 dBm fixed
                       /   \
              SBS ●         ● SBS
             /                  \
        SBS ●      30 UEs        ● SBS
             \     (mobile)    /
              SBS ●         ● SBS
                       ●
                      SBS

  Radius: 500m (UE area)   Ring: 250m (SBS)
```

| Node | Count | TX Power | Height |
|------|-------|----------|--------|
| Macro BS (MBS) | 1 | 46 dBm (fixed) | 25 m |
| Small BS (SBS) | 6 | 20 / 30 / 40 dBm (DRL-controlled) | 10 m |
| User Equipment | 30 | — | 1.5 m |

---

## Energy Model

Based on **Auer et al. 2011 (EARTH project)**:

```
P_BS = P0 + Δp · Pout
```

| Parameter | MBS | SBS |
|-----------|-----|-----|
| P₀ (idle power) | 130 W | 6.8 W |
| Δp (load slope) | 4.7 | 4.0 |
| Pmax | 40 W | 6.3 W |
| Psleep | 75 W | 2.9 W |

**Energy Efficiency** = Total Throughput (bits/s) / P_BS (W)

---

## Reward Function

```
R = 0.40 · tanh(EE/10) + 0.25 · Fairness − 0.20 · PowerNorm − 0.15 · HOPenalty
```

Where:
- `EE` = energy efficiency (Mbits/J)
- `Fairness` = Jain's fairness index ∈ [0,1]
- `PowerNorm` = normalised TX power ∈ [0,1]
- `HOPenalty` = handover penalty ∈ [0,1]

---

## Dataset Columns

| Column | Unit | Description |
|--------|------|-------------|
| `episode` | — | Episode index (0–3) |
| `time_step` | — | Control step within episode |
| `time_s` | s | Simulation time |
| `bs_id` | — | Base station ID (0=MBS, 1–6=SBS) |
| `bs_type` | — | `MBS` or `SBS` |
| `ue_count` | — | Attached UEs |
| `prb_utilization` | [0,1] | Physical Resource Block utilisation |
| `tx_power_dbm` | dBm | Transmit power |
| `action` | {0,1,2} | DRL action: LOW/MED/HIGH |
| `avg_sinr_db` | dB | Mean SINR across attached UEs |
| `min_sinr_db` | dB | Worst-case SINR |
| `max_sinr_db` | dB | Best-case SINR |
| `avg_rsrp_dbm` | dBm | Reference Signal Received Power |
| `throughput_mbps` | Mbps | Aggregate Shannon throughput |
| `interference_dbm` | dBm | Co-channel interference |
| `energy_consumed_w` | W | Auer 2011 BS power consumption |
| `energy_efficiency` | Mbits/J | Throughput per watt |
| `latency_ms` | ms | M/D/1 approximated latency |
| `fairness_index` | [0,1] | Jain's fairness index |
| `handover_count` | — | Handover events this step |
| `reward` | ℝ | Composite DRL reward |

---

## Quick Start

### Option A — No NS-3 required (same physics, instant)

```bash
git clone https://github.com/<your-username>/marl_5g_hetnet.git
cd marl_5g_hetnet

pip install -r requirements.txt

# 1. Generate dataset (Python physics replica of NS-3 sim)
python3 generate_dataset_standalone.py

# 2. Post-process
python3 process_ns3_output.py

# 3. Train
python3 train_mappo.py

# 4. Visualise
python3 plot_results.py
```

### Option B — Full NS-3 simulation

```bash
# Install NS-3 on WSL Ubuntu (one-time, ~15 min)
chmod +x scripts/install_ns3_wsl.sh
./scripts/install_ns3_wsl.sh

# Run full simulation → hetnet_dataset.csv
chmod +x scripts/run_simulation.sh
./scripts/run_simulation.sh

# Then continue from step 2 above
python3 process_ns3_output.py
python3 train_mappo.py
python3 plot_results.py
```

---

## NS-3 Setup (WSL Ubuntu)

### Prerequisites

```bash
sudo apt update && sudo apt install -y \
    build-essential cmake g++ python3 python3-pip git wget \
    libxml2-dev libgsl-dev libsqlite3-dev libboost-all-dev
```

### Manual NS-3 build

```bash
cd ~
wget https://www.nsnam.org/releases/ns-allinone-3.42.tar.bz2
tar xjf ns-allinone-3.42.tar.bz2
cd ns-allinone-3.42/ns-3.42

# Copy simulation
cp /path/to/repo/ns3/scratch/hetnet_5g_sim.cc scratch/

# Configure + build
./ns3 configure --build-profile=optimized --disable-examples --disable-tests
./ns3 build

# Run
./ns3 run "hetnet_5g_sim --seed=42"
mv hetnet_dataset.csv /path/to/repo/
```

---

## Training

```bash
# Full training (60 epochs, Transformer-MAPPO)
python3 train_mappo.py

# Monitor results
ls results/
#   mappo_model.pth      ← trained weights
#   loss_history.npy     ← per-epoch loss
#   reward_history.npy   ← per-epoch reward
#   train.csv / val.csv / test.csv
#   states.npy [T,7,7]  actions.npy  rewards.npy
```

### Hyperparameters

| Parameter | Value |
|-----------|-------|
| Embed dim | 128 |
| Transformer layers | 3 |
| Attention heads | 4 |
| Learning rate | 3e-4 (CosineAnnealing) |
| PPO clip ε | 0.2 |
| GAE λ | 0.95 |
| Discount γ | 0.99 |
| Entropy coeff | 0.01 |
| Batch size | 64 |
| Epochs | 60 |

---

## Results

After full training on 4-episode NS-3 dataset:

| Metric | Value |
|--------|-------|
| Avg Throughput | ~147 Mbps |
| Avg SINR | ~−4 dB |
| Energy Efficiency | ~13.8 Mbits/J |
| Jain Fairness | ~0.88 |
| Avg Latency | ~3.9 ms |
| Model Parameters | 481,796 |

---

## Project Structure

```
marl_5g_hetnet/
├── ns3/
│   └── scratch/
│       └── hetnet_5g_sim.cc          # NS-3 C++ simulation
├── src/
│   ├── agents/
│   │   └── transformer_mappo.py      # Transformer-MAPPO model
│   ├── env/
│   │   └── replay_buffer.py          # Optimised replay buffer
│   └── utils/
│       └── ppo_infer.py              # Real-time PPO inference
├── scripts/
│   ├── install_ns3_wsl.sh            # NS-3 installer (WSL Ubuntu)
│   └── run_simulation.sh             # Full pipeline runner
├── generate_dataset_standalone.py    # Python NS-3 physics replica
├── process_ns3_output.py             # Post-processing pipeline
├── train_mappo.py                    # Training entry point
├── plot_results.py                   # Research visualisation (13 plots)
├── results/
│   ├── plots/                        # Generated PNG plots
│   ├── models/                       # Saved .pth checkpoints
│   └── data/                         # Processed .npy tensors
├── requirements.txt
└── README.md
```

---

## Citation

If you use this code in your research, please cite:

```bibtex
@software{marl_5g_hetnet_2025,
  title   = {MA-DRL 5G HetNet: Multi-Agent Deep Reinforcement Learning
             for Adaptive Energy-Efficient Optimization in 5G Heterogeneous Networks},
  author  = {Atul},
  year    = {2025},
  url     = {https://github.com/<your-username>/marl_5g_hetnet},
  note    = {NS-3 simulation + Transformer-MAPPO implementation}
}
```

### Related Work

- Auer, G. et al. (2011). How much energy is needed to run a wireless network? *IEEE Wireless Commun.*
- Venkateswararao et al. (2023). DRL for 5G HetNet power optimisation.
- Yu, C. et al. (2022). The Surprising Effectiveness of PPO in Cooperative Multi-Agent Games. *NeurIPS*.

---

## License

MIT License — see [LICENSE](LICENSE) for details.

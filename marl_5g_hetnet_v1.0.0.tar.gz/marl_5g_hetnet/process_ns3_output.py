# =============================================================================
# process_ns3_output.py
# Post-process the raw NS-3 hetnet_dataset.csv:
#   1. Clean & validate columns
#   2. Add derived features (delta_throughput, load_class, SINR bin, etc.)
#   3. Normalise for DRL training
#   4. Split into train / val / test sets
#   5. Save processed files to results/
# =============================================================================

import os
import sys
import numpy as np
import pandas as pd
from pathlib import Path

# ─── paths ────────────────────────────────────────────────────────────────────
CSV_IN  = "hetnet_dataset.csv"
OUT_DIR = Path("results")
OUT_DIR.mkdir(exist_ok=True)

# ─── expected columns ─────────────────────────────────────────────────────────
REQUIRED = [
    "episode", "time_step", "time_s",
    "bs_id", "bs_type",
    "ue_count", "prb_utilization",
    "tx_power_dbm", "action",
    "avg_sinr_db", "min_sinr_db", "max_sinr_db",
    "avg_rsrp_dbm",
    "throughput_mbps",
    "interference_dbm",
    "energy_consumed_w", "energy_efficiency",
    "latency_ms",
    "fairness_index",
    "handover_count",
    "reward",
]

# ─── Auer 2011 constants (for verification) ───────────────────────────────────
AUER = {
    "MBS": dict(P0=130.0, delta_p=4.7, Pmax=40.0, Psleep=75.0),
    "SBS": dict(P0=6.8,   delta_p=4.0, Pmax=6.3,  Psleep=2.9),
}

print("=" * 60)
print("  NS-3 HetNet Dataset Post-Processor")
print("=" * 60)

# ─── load ─────────────────────────────────────────────────────────────────────
if not os.path.exists(CSV_IN):
    sys.exit(f"[ERROR] {CSV_IN} not found. Run the NS-3 simulation first.")

print(f"Loading {CSV_IN} ...")
df = pd.read_csv(CSV_IN)

print(f"  Raw shape : {df.shape}")
print(f"  Columns   : {list(df.columns)}")

# ─── validate columns ─────────────────────────────────────────────────────────
missing = [c for c in REQUIRED if c not in df.columns]
if missing:
    sys.exit(f"[ERROR] Missing columns: {missing}")

# ─── basic cleaning ───────────────────────────────────────────────────────────
df = df.dropna()
df = df.drop_duplicates()

# Clip physically implausible values
df["avg_sinr_db"]      = df["avg_sinr_db"].clip(-30, 40)
df["throughput_mbps"]  = df["throughput_mbps"].clip(0, 500)
df["energy_consumed_w"]= df["energy_consumed_w"].clip(0, 500)
df["latency_ms"]       = df["latency_ms"].clip(0.1, 1000)
df["fairness_index"]   = df["fairness_index"].clip(0, 1)
df["prb_utilization"]  = df["prb_utilization"].clip(0, 1)

print(f"  After cleaning : {df.shape}")

# ─── derived features ─────────────────────────────────────────────────────────
# 1. SINR quality class
bins   = [-np.inf, -5, 0, 5, 10, 20, np.inf]
labels = ["very_poor", "poor", "fair", "good", "very_good", "excellent"]
df["sinr_class"] = pd.cut(df["avg_sinr_db"], bins=bins, labels=labels)

# 2. Load class
df["load_class"] = pd.cut(
    df["prb_utilization"],
    bins=[0, 0.2, 0.5, 0.8, 1.01],
    labels=["light", "moderate", "heavy", "overloaded"],
    include_lowest=True
)

# 3. Delta throughput (per BS, per episode – change from previous step)
df = df.sort_values(["episode", "bs_id", "time_step"])
df["delta_throughput"] = df.groupby(["episode", "bs_id"])["throughput_mbps"].diff().fillna(0)

# 4. Rolling average reward (window = 10 steps)
df["reward_ma10"] = (
    df.groupby(["episode", "bs_id"])["reward"]
      .transform(lambda x: x.rolling(10, min_periods=1).mean())
)

# 5. Power saving vs max power
df["power_saving_pct"] = (1.0 - (df["energy_consumed_w"] /
    df["bs_type"].map({"MBS": 130 + 4.7*40, "SBS": 6.8 + 4.0*6.3}))) * 100
df["power_saving_pct"] = df["power_saving_pct"].clip(0, 100)

# 6. UE density (UEs per km², assuming 500m radius cell for MBS, 200m for SBS)
cell_areas = {"MBS": np.pi * 0.5**2, "SBS": np.pi * 0.2**2}  # km²
df["ue_density"] = df.apply(
    lambda r: r["ue_count"] / cell_areas.get(r["bs_type"], 0.1), axis=1
)

# 7. Spectral efficiency (bps/Hz)
df["spectral_efficiency"] = (df["throughput_mbps"] * 1e6) / 20e6  # 20 MHz BW

# 8. BS type indicator
df["is_sbs"] = (df["bs_type"] == "SBS").astype(int)

print("  Derived features added.")

# ─── episode statistics ───────────────────────────────────────────────────────
ep_stats = df.groupby("episode").agg(
    avg_reward      = ("reward",           "mean"),
    avg_throughput  = ("throughput_mbps",  "mean"),
    avg_energy      = ("energy_consumed_w","mean"),
    avg_ee          = ("energy_efficiency","mean"),
    avg_fairness    = ("fairness_index",   "mean"),
    avg_sinr        = ("avg_sinr_db",      "mean"),
    total_handovers = ("handover_count",   "sum"),
    steps           = ("time_step",        "nunique"),
)
print("\n  Episode summary:")
print(ep_stats.to_string())

# ─── per-BS statistics ────────────────────────────────────────────────────────
bs_stats = df.groupby(["bs_id", "bs_type"]).agg(
    avg_tp     = ("throughput_mbps",  "mean"),
    avg_ee     = ("energy_efficiency","mean"),
    avg_sinr   = ("avg_sinr_db",      "mean"),
    avg_reward = ("reward",           "mean"),
    n_rows     = ("reward",           "count"),
).reset_index()
print("\n  Per-BS summary:")
print(bs_stats.to_string())

# ─── normalisation for DRL ────────────────────────────────────────────────────
NORM_COLS = [
    "avg_sinr_db", "min_sinr_db", "max_sinr_db", "avg_rsrp_dbm",
    "throughput_mbps", "interference_dbm",
    "energy_consumed_w", "energy_efficiency",
    "latency_ms", "prb_utilization", "ue_count",
    "fairness_index", "tx_power_dbm",
]

df_norm = df.copy()
stats_dict = {}
for col in NORM_COLS:
    mu  = df[col].mean()
    sig = df[col].std() + 1e-8
    df_norm[col + "_norm"] = (df[col] - mu) / sig
    stats_dict[col] = {"mean": float(mu), "std": float(sig)}

# Save normalisation stats
import json
with open(OUT_DIR / "norm_stats.json", "w") as f:
    json.dump(stats_dict, f, indent=2)
print("\n  Normalisation stats → results/norm_stats.json")

# ─── train / val / test split (by episode) ────────────────────────────────────
episodes = sorted(df["episode"].unique())
n_ep     = len(episodes)
n_train  = max(1, int(n_ep * 0.70))
n_val    = max(1, int(n_ep * 0.15))

train_ep = episodes[:n_train]
val_ep   = episodes[n_train:n_train + n_val]
test_ep  = episodes[n_train + n_val:]

df_train = df[df["episode"].isin(train_ep)]
df_val   = df[df["episode"].isin(val_ep)]
df_test  = df[df["episode"].isin(test_ep)]

df_train.to_csv(OUT_DIR / "train.csv", index=False)
df_val.to_csv(  OUT_DIR / "val.csv",   index=False)
df_test.to_csv( OUT_DIR / "test.csv",  index=False)

print(f"\n  Split → train:{len(df_train)}  val:{len(df_val)}  test:{len(df_test)}")

# ─── save full processed ─────────────────────────────────────────────────────
df.to_csv(OUT_DIR / "hetnet_processed.csv", index=False)
print(f"  Full processed → results/hetnet_processed.csv  ({len(df)} rows)")

# ─── build RL state matrix ───────────────────────────────────────────────────
# State per (episode, time_step): concatenate all BS features → flat vector
STATE_FEATURES = [
    "avg_sinr_db", "throughput_mbps", "energy_efficiency",
    "prb_utilization", "ue_count", "fairness_index", "latency_ms",
]

print("\n  Building RL state tensors...")

# For MAPPO: each BS is an agent → state shape [T, N_agents, state_dim]
all_states  = []
all_actions = []
all_rewards = []

for (ep, ts), grp in df.groupby(["episode", "time_step"]):
    grp_sorted = grp.sort_values("bs_id")
    if len(grp_sorted) != 7:          # 1 MBS + 6 SBS
        continue
    s = grp_sorted[STATE_FEATURES].values.astype(np.float32)
    a = grp_sorted["action"].values.astype(np.int32)
    r = grp_sorted["reward"].values.astype(np.float32)
    all_states.append(s)
    all_actions.append(a)
    all_rewards.append(r)

if all_states:
    states_arr  = np.stack(all_states)   # [T, 7, state_dim]
    actions_arr = np.stack(all_actions)  # [T, 7]
    rewards_arr = np.stack(all_rewards)  # [T, 7]

    np.save(OUT_DIR / "states.npy",  states_arr)
    np.save(OUT_DIR / "actions.npy", actions_arr)
    np.save(OUT_DIR / "rewards.npy", rewards_arr)

    print(f"  states.npy  : {states_arr.shape}")
    print(f"  actions.npy : {actions_arr.shape}")
    print(f"  rewards.npy : {rewards_arr.shape}")

# ─── summary ──────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("  PERFORMANCE SUMMARY  (full dataset)")
print("=" * 60)
print(f"  Average Throughput    : {df['throughput_mbps'].mean():.3f} Mbps")
print(f"  Average SINR          : {df['avg_sinr_db'].mean():.3f} dB")
print(f"  Average Energy        : {df['energy_consumed_w'].mean():.3f} W")
print(f"  Average EE            : {df['energy_efficiency'].mean():.4f} Mbits/J")
print(f"  Average Fairness      : {df['fairness_index'].mean():.4f}")
print(f"  Average Latency       : {df['latency_ms'].mean():.3f} ms")
print(f"  Average Reward        : {df['reward'].mean():.4f}")
print(f"  Total Handovers       : {df['handover_count'].sum()}")
print("=" * 60)
print("  Post-processing complete!")
